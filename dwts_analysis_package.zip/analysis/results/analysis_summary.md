# DWTS Factor Analysis Summary (Fixed)

- Contestants: 421
- Seasons: 34
- Leakage for Success enabled? False

## Drivers of Success (Placement)

Top 10 features by mean absolute SHAP:

| feature_clean            |   signed_shap |   mean_abs_shap |
|:-------------------------|--------------:|----------------:|
| Early Performance (W1-2) |   0.00386169  |      0.158187   |
| age                      |  -0.00202595  |      0.0535386  |
| Partner: Other_Partner   |   1.95439e-05 |      0.00686233 |
| State: California        |   7.19688e-05 |      0.00681098 |
| Industry: Singer/Rapper  |   0.00021543  |      0.0068049  |
| Industry: TV Personality |  -0.000412601 |      0.00525538 |
| Industry: Model          |   0.000816692 |      0.00520281 |
| Partner: Cheryl Burke    |  -0.000453907 |      0.00465406 |
| State: Illinois          |  -0.000173097 |      0.00287122 |
| State: Texas             |  -0.000331713 |      0.0027954  |

## Drivers of Judge Appeal (Avg Score)

Top 10 features by mean absolute SHAP:

| feature_clean            |   signed_shap |   mean_abs_shap |
|:-------------------------|--------------:|----------------:|
| Early Performance (W1-2) |   0.0117035   |      0.918431   |
| age                      |  -0.00096226  |      0.163781   |
| Partner: Other_Partner   |  -0.00169945  |      0.0499028  |
| Industry: TV Personality |  -6.99732e-05 |      0.0138473  |
| Industry: Athlete        |   0.000382252 |      0.00975031 |
| Industry: Singer/Rapper  |  -0.000390322 |      0.00917242 |
| Partner: Cheryl Burke    |  -0.00130368  |      0.0072075  |
| Industry: Other          |  -0.000856788 |      0.00616774 |
| State: Other_State       |   0.000977782 |      0.00548421 |
| State: Texas             |  -0.000686344 |      0.00456446 |

## Drivers of Fan Appeal (Avg Share)

Top 10 features by mean absolute SHAP:

| feature_clean            |   signed_shap |   mean_abs_shap |
|:-------------------------|--------------:|----------------:|
| Early Performance (W1-2) |   0.00138427  |     0.0365157   |
| age                      |  -0.000200074 |     0.00758093  |
| Partner: Derek Hough     |  -0.000951057 |     0.00447749  |
| State: Other_State       |  -3.0401e-05  |     0.00109006  |
| Partner: Other_Partner   |   7.20899e-05 |     0.000829883 |
| State: Georgia           |  -7.45088e-05 |     0.000814847 |
| State: Louisiana         |  -0.00013504  |     0.000737344 |
| State: California        |   2.98782e-05 |     0.000699406 |
| State: Pennsylvania      |  -4.6511e-05  |     0.00069837  |
| State: Illinois          |  -5.72966e-05 |     0.000679815 |

